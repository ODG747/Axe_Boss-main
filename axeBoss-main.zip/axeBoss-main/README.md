# axeBoss

Preview : https://youtu.be/95rXmXHWN-k
<p>
Discord : https://discord.gg/5dev

・Création de menu boss pour entreprise/gang/organisation
 <p>
・Création sans avoir à reboot 
 <p>
・Choix du marker 
<p>
・Annonce si c'est une entreprise
<p>
・Gestion argent
<p>
・Gestion des salaires
<p>
・Gestion des membres
<p>

Le script a été réalisé par Amauu#0001 et je suis re passé derrière lui pour combler et "finir" le script, Revente et appropriation non autorisée.
 
